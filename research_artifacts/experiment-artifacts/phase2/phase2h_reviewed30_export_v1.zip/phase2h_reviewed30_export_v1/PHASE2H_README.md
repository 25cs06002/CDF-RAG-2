# Phase 2H — Initial 30-question reviewed-candidate export

**Status:** Reviewer workflow-complete, **not** medical gold / not clinically or independently adjudicated. Do not load retained relationships into a production or evaluation medical knowledge graph without adjudication.

## Input and freeze

The three uploaded files were checked against the frozen SHA-256 hashes reported by the reviewer:

- `claim_review.csv`: `668180af5b882eccb7df8079dd38eb5b27a43e7910ba334938bc01c98fe1d75e`
- `question_review.csv`: `f022de5c7a9abdd39ea2329b93dd8af5dcacc0ac9a20313903f9ebff8aa78c1a`
- `review_manifest.json`: `ebc1822550c2dce9aae7dc1efc9257183cc605fa5e20609628840b4a019ee10c`

The user ran `python3 -m research_v2.reviewer_workspace --audit-dir "$REVIEW_DIR" --strict` successfully with **0 pending**. This ZIP's profile records that *user-reported* audit; the included module **re-runs** the strict audit when executing locally from the repository.

## Outputs

- `reviewed_relationships_v1.jsonl` — 22 relationship **candidates** (20 accepted, 2 revised). Both original and effective candidate claim are stored. Must not be called medical gold.
- `unresolved_relationships_v1.jsonl` — 3 needs-more-evidence tasks, including the asthma source gap.
- `reviewed_questions_v1.jsonl` — 28 answerable question **drafts**, with source references and family identifiers, split unset.
- `unresolved_questions_v1.jsonl` — 2 questions needing more evidence (asthma onset, not triggers).
- `export_profile.json` — counts, original input hashes, reviewer audit status and unresolved coherence warnings.
- `SHA256SUMS.txt` — checksums for the five outputs.

**Evidence coherence warning:** `PILOT_005` and `PILOT_020` are answerable from the registered weight-management topic source, although both obesity-specific proposed relationships `EVP006:R01/R02` are unresolved. Do not use those questions to score causal-edge/path recovery absent separate adjudication.

**Graph modeling:** `EVP003:R02` changes compound “air pollution and dust” to “long-term exposure to air pollution” for the candidate `RISK_FACTOR_FOR` edge. Dust and chemical fumes would require their own individually evidenced review entries. `EVP015:R02` narrows a generic thyroid removal cause to **complete** surgical removal. The exporter preserves both original and reviewed forms.

## Reproduce locally on `research-v2`

Run after the Phase 2H module is installed in `research_v2/reviewed_export.py`:

```bash
cd ~/Folder/CDF-RAG-2
source venv/bin/activate
export FREEZE_DIR="$HOME/Folder/CDF-RAG-2-experiment-artifacts/phase2/reviewed30_frozen_v1"
cd "$FREEZE_DIR" && sha256sum -c SHA256SUMS.txt
cd ~/Folder/CDF-RAG-2
OUT="$HOME/Folder/CDF-RAG-2-experiment-artifacts/phase2/reviewed30_export_$(date -u +%Y%m%dT%H%M%SZ)"
python3 -m research_v2.reviewed_export \
  --review-dir "$FREEZE_DIR" \
  --checksums-file "$FREEZE_DIR/SHA256SUMS.txt" \
  --output-dir "$OUT"
(cd "$OUT" && sha256sum -c SHA256SUMS.txt)
```

The output directory must not preexist. The exporter **refuses** to bypass the strict worksheet audit and never writes gold labels, partitions, PPO training inputs or graph import files.

## Next research tasks

1. Independently adjudicate retained causal relationship type, causal direction, source locator and original-vs-corrected concepts; preserve reviewer conflict/resolution history.
2. Resolve the three unresolved claim tasks and two asthma onset questions using appropriate onset-specific sources; leave them unresolved if the corpus is insufficient.
3. Expand 70-question source queue into the same reviewed workflow, separately tracking multi-hop path evidence and negative/abstention cases.
4. Assign train/validation/test partitions only after coverage review, grouping by question, concept and source families to prevent leakage.
5. Produce final gold only after the necessary clinical/domain-quality evidence and adjudication checks.
